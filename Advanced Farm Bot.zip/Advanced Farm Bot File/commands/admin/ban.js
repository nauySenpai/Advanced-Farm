const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'ban',
    description: 'Cấm người dùng sử dụng bot.',
    execute(message, args, client, data, config) {
        if (message.author.id !== config.ownerId) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        const user = message.mentions.users.first();
        if (!user) return message.reply('Vui lòng đề cập đến người dùng cần cấm.');

        const duration = args[1] ? parseInt(args[1], 10) : 0;
        const isPermanent = duration === 0;

        if (isNaN(duration) && !isPermanent) {
            return message.reply('Thời gian cấm phải là một số hoặc để trống để cấm vĩnh viễn.');
        }

        if (!data.banned.includes(user.id)) {
            data.banned.push(user.id);
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setTitle('🔨 Người dùng bị cấm')
                .setDescription(`${user.tag} đã bị cấm sử dụng bot${isPermanent ? ' vĩnh viễn' : ` trong ${duration} giờ`}.`);
            message.reply({ embeds: [embed] });

            if (!isPermanent) {
                setTimeout(() => {
                    const index = data.banned.indexOf(user.id);
                    if (index > -1) data.banned.splice(index, 1);
                }, duration * 60 * 60 * 1000);
            }
        } else {
            message.reply('Người dùng này đã bị cấm trước đó.');
        }
    },
};

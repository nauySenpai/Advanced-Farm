const { EmbedBuilder } = require('discord.js');
const fs = require('fs');

module.exports = {
    name: 'resetdata',
    description: 'Xóa dữ liệu người dùng.',
    execute(message, args, client, data, config) {
        if (message.author.id !== config.ownerId) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        const user = message.mentions.users.first();
        if (args[0] === 'all') {
            data.users = {};
            fs.writeFileSync('./data/data.json', JSON.stringify(data, null, 2));
            return message.reply('Đã xóa dữ liệu của tất cả người dùng.');
        }

        if (!user) return message.reply('Vui lòng đề cập đến người dùng cần xóa dữ liệu.');

        delete data.users[user.id];
        fs.writeFileSync('./data/data.json', JSON.stringify(data, null, 2));

        const embed = new EmbedBuilder()
            .setColor('#FF0000')
            .setTitle('⚠️ Dữ liệu đã được reset')
            .setDescription(`Dữ liệu của ${user.tag} đã được xóa.`);
        message.reply({ embeds: [embed] });
    },
};

const { EmbedBuilder } = require('discord.js');
const fs = require('fs');

module.exports = {
    name: 'setprefix',
    description: 'Đặt prefix cho bot.',
    execute(message, args, client, data, config) {
        if (message.author.id !== config.ownerId) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        const newPrefix = args[0];
        if (!newPrefix) return message.reply('Hãy nhập prefix mới.');

        config.prefix = newPrefix;

        fs.writeFileSync('./config.json', JSON.stringify(config, null, 2));
        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🔧 Prefix đã thay đổi')
            .setDescription(`Prefix mới là \`${newPrefix}\`.`);
        message.reply({ embeds: [embed] });
    },
};

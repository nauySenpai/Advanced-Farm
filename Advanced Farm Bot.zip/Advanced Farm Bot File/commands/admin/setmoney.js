const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'set',
    description: 'Đặt tiền cho người dùng.',
    execute(message, args, client, data, config) {
        if (message.author.id !== config.ownerId) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        const user = message.mentions.users.first();
        const amount = parseInt(args[1], 10);

        if (!user || isNaN(amount)) {
            return message.reply('Cú pháp: `set <@người-dùng> <số-tiền>`.');
        }

        if (!data.users[user.id]) {
            return message.reply('Người dùng này không tồn tại trong dữ liệu.');
        }

        data.users[user.id].money = amount;
        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('💰 Tiền đã được đặt')
            .setDescription(`Số tiền của ${user.tag} đã được đặt thành ${amount} ${config.currency.icon}.`);
        message.reply({ embeds: [embed] });
    },
};

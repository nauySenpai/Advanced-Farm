const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'add',
    description: 'Thêm tiền cho người dùng.',
    execute(message, args, client, data, config) {
        if (message.author.id !== config.ownerId) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        const user = message.mentions.users.first();
        const amount = parseInt(args[1], 10);

        if (!user || isNaN(amount)) {
            return message.reply('Cú pháp: `add <@người-dùng> <số-tiền>`.');
        }

        if (!data.users[user.id]) {
            return message.reply('Người dùng này không tồn tại trong dữ liệu.');
        }

        data.users[user.id].money += amount;
        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('💰 Tiền đã được thêm')
            .setDescription(`${amount} ${config.currency.icon} đã được thêm cho ${user.tag}.`);
        message.reply({ embeds: [embed] });
    },
};

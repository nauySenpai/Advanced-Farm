const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'bag',
    description: 'Xem túi đồ của bạn.',
    execute(message, args, client, data, config) {
        const userId = message.author.id;
        const userData = data.users[userId];

        const plants = Object.entries(userData.plants)
            .map(([name, quantity]) => `${config.farm.plants[name].icon} ${name}: ${quantity}`)
            .join('\n');

        const animals = Object.entries(userData.animals)
            .map(([name, quantity]) => `${config.farm.animals[name].icon} ${name}: ${quantity}`)
            .join('\n');

        const fishes = Object.entries(userData.fishes)
            .map(([name, quantity]) => `${config.fishing.fishs[name].icon} ${name}: ${quantity}`)
            .join('\n');

        const rod = userData.currentRod
            ? `${config.fishing.rods[userData.currentRod].icon} ${userData.currentRod}`
            : 'Không có cần câu';

        const embed = new EmbedBuilder()
            .setColor('#00FFFF')
            .setTitle('🎒 Túi đồ của bạn')
            .addFields(
                { name: 'Cần câu hiện tại', value: rod, inline: false },
                { name: '🌾 Cây trồng', value: plants || 'Không có cây trồng.', inline: false },
                { name: '🐾 Động vật', value: animals || 'Không có động vật.', inline: false },
                { name: '🐟 Cá', value: fishes || 'Không có cá.', inline: false }
            );

        message.reply({ embeds: [embed] });
    },
};

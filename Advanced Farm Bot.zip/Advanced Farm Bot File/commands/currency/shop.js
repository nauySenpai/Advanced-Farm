const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'shop',
    description: 'Xem các vật phẩm có thể mua.',
    execute(message, args, client, data, config) {
        const plants = Object.entries(config.farm.plants)
            .map(([name, details]) => `**${details.icon} ${name}** - ${details.price} ${config.currency.icon}\nthu hoạch được ${details.uses} lần - ${details.reward} ${config.currency.name}/1 lần`)
            .join('\n');

        const animals = Object.entries(config.farm.animals)
            .map(([name, details]) => `**${details.icon} ${name}** - ${details.price} ${config.currency.icon}\nnuôi được ${details.uses} lần - ${details.reward} ${config.currency.name}/1 lần`)
            .join('\n');

        const rods = Object.entries(config.fishing.rods)
            .map(([name, details]) => `**${details.icon} ${name}** - ${details.price} ${config.currency.icon}\ncâu được ${details.catch} cá/1 lần`)
            .join('\n');

        const embed = new EmbedBuilder()
            .setColor('#00FFFF')
            .setTitle('🛒 Cửa hàng')
            .setDescription('Dưới đây là danh sách các vật phẩm bạn có thể mua:')
            .addFields(
                { name: '🌾 Cây trồng', value: plants || 'Không có vật phẩm.', inline: false },
                { name: '🐾 Động vật', value: animals || 'Không có vật phẩm.', inline: false },
                { name: '🎣 Cần câu', value: rods || 'Không có vật phẩm.', inline: false },
                { name: '** **', value: 'mua bằng lệnh `f!buy <tên-vật-phẩm> <số-lượng>`', inline: false }
            );

        message.reply({ embeds: [embed] });
    },
};

const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'leaderboard',
    description: 'Xem bảng xếp hạng.',
    execute(message, args, client, data, config) {
        const leaderboard = Object.entries(data.users)
            .filter(([id, user]) => user.money > 0)
            .sort((a, b) => b[1].money - a[1].money)
            .slice(0, 10)
            .map(([id, user], index) => `${index + 1}. <@${id}> - ${user.money} ${config.currency.icon}`);

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('🏆 Bảng xếp hạng')
            .setDescription(leaderboard.length > 0 ? leaderboard.join('\n') : 'Chưa có ai trong bảng xếp hạng.')
            .setFooter({ text: 'Hãy cố gắng để leo lên top!' });

        message.reply({ embeds: [embed] });
    },
};

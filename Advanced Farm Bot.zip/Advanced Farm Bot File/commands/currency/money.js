const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'money',
    description: 'Xem số dư của bạn.',
    execute(message, args, client, data, config) {
        const userId = message.author.id;
        const userData = data.users[userId];

        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('💰 Số dư của bạn')
            .setDescription(`Bạn hiện có ${userData.money} ${config.currency.icon} (${config.currency.name}).`)
            .setFooter({ text: 'Kiểm tra số dư của bạn thường xuyên!' });

        message.reply({ embeds: [embed] });
    },
};

const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'buy',
    description: 'Mua vật phẩm từ cửa hàng.',
    execute(message, args, client, data, config) {
        const userId = message.author.id;
        const userData = data.users[userId];
        const item = args[0]?.toLowerCase();
        const quantity = parseInt(args[1], 10) || 1;

        if (!item || quantity <= 0) {
            return message.reply('Cú pháp: `buy <tên-vật-phẩm> <số-lượng>`.');
        }

        const categories = { ...config.farm.plants, ...config.farm.animals, ...config.fishing.rods };
        const selectedItem = categories[item];

        if (!selectedItem) {
            return message.reply('Vật phẩm này không tồn tại trong cửa hàng.');
        }

        const cost = selectedItem.price * quantity;
        if (userData.money < cost) {
            return message.reply('Bạn không đủ tiền để mua vật phẩm này.');
        }

        userData.money -= cost;
        if (config.farm.plants[item]) userData.plants[item] = (userData.plants[item] || 0) + quantity;
        if (config.farm.animals[item]) userData.animals[item] = (userData.animals[item] || 0) + quantity;
        if (config.fishing.rods[item]) userData.currentRod = item;

        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('✅ Đã mua vật phẩm')
            .setDescription(
                `Bạn đã mua ${quantity} **${selectedItem.icon} ${item}** với giá ${cost} ${config.currency.icon}.`
            );

        message.reply({ embeds: [embed] });
    },
};

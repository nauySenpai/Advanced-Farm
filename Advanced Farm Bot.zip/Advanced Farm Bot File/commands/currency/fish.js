const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'fish',
    description: 'Câu cá để kiếm tiền.',
    execute(message, args, client, data, config) {
        const userId = message.author.id;
        const cooldown = config.cooldowns.fish;
        const userData = data.users[userId];
        const now = Date.now();

        if (now - userData.cooldowns.fish < cooldown) {
            const timeLeft = Math.ceil((cooldown - (now - userData.cooldowns.fish)) / 1000);
            return message.reply(`Bạn cần chờ thêm ${timeLeft} giây để câu cá tiếp.`);
        }

        const currentRod = userData.currentRod;
        if (!currentRod || !config.fishing.rods[currentRod]) {
            return message.reply('Bạn cần sở hữu một cần câu để câu cá. Hãy mua trong cửa hàng bằng lệnh `shop`.');
        }

        userData.cooldowns.fish = now;
        
        // Xác định kết quả câu cá
        const random = Math.random();
        const fishes = Object.entries(config.fishing.fishs).filter(([name, fish]) => random < fish.chance);

        if (fishes.length === 0) {
            return message.reply('Bạn đã không câu được con cá nào. Thử lại lần sau nhé!');
        }

        const [caughtFish, fishDetails] = fishes[0];
        const rodDetails = config.fishing.rods[currentRod];
        userData.fishes[caughtFish] = (userData.fishes[caughtFish]) + rodDetails.catch;


        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🎣 Bạn đã câu được cá!')
            .setDescription(
                `Chúc mừng! Bạn đã câu được **${rodDetails.catch}x ${fishDetails.icon} ${caughtFish}**.`
            );

        message.reply({ embeds: [embed] });
    },
};

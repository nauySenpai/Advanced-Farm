const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'farm',
    description: 'Thu hoạch nông trại để kiếm tiền.',
    execute(message, args, client, data, config) {
        const userId = message.author.id;
        const userData = data.users[userId];
        const cooldown = config.cooldowns.farm;
        const now = Date.now();
        let earnings = 0;

        if (now - userData.cooldowns.farm < cooldown) {
            const timeLeft = Math.ceil((cooldown - (now - userData.cooldowns.farm)) / 1000);
            return message.reply(`Bạn cần chờ thêm ${timeLeft} giây để thu hoạch tiếp.`);
        }

        userData.cooldowns.farm = now;

        for (const [plant, details] of Object.entries(config.farm.plants)) {
            if (userData.plants[plant] > 0) {
                const harvestable = Math.min(details.uses, userData.plants[plant]);
                earnings += harvestable * details.reward;
                userData.plants[plant] -= harvestable;
            }
        }

        for (const [animal, details] of Object.entries(config.farm.animals)) {
            if (userData.animals[animal] > 0) {
                const harvestable = Math.min(details.uses, userData.animals[animal]);
                earnings += harvestable * details.reward;
                userData.animals[animal] -= harvestable;
            }
        }
        
        for (const [fish, details] of Object.entries(config.fishing.fishs)) {
            if (userData.fishes[fish] > 0) {
                const harvestable = Math.min(details.uses, userData.fishes[fish]);
                earnings += harvestable * details.reward;
                userData.fishes[fish] -= harvestable;
            }
        }

        userData.money += earnings;
        const embed = new EmbedBuilder()
            .setColor('#00FF00')
            .setTitle('🌾 Thu hoạch nông trại')
            .setDescription(
                `Bạn đã thu hoạch và kiếm được ${earnings} ${config.currency.icon} từ nông trại của mình.`
            )
            .setFooter({ text: 'Hãy tiếp tục mua nhiều nông sản, gia súc để kiếm nhiều tiền hơn!' });

        message.reply({ embeds: [embed] });
    },
};
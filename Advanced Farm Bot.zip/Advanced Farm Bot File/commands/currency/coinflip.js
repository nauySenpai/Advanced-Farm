const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'coinflip',
    description: 'Cá cược tiền.',
    execute(message, args, client, data, config) {
        const userId = message.author.id;
        const userData = data.users[userId];
        const cooldown = config.cooldowns.coinflip;
        const now = Date.now();

        if (now - userData.cooldowns.coinflip < cooldown) {
            const timeLeft = Math.ceil((cooldown - (now - userData.cooldowns.coinflip)) / 1000);
            return message.reply(`Bạn cần chờ thêm ${timeLeft} giây để cá cược tiếp.`);
        }

        const betAmount = parseInt(args[0], 10);
        if (isNaN(betAmount) || betAmount <= 0) {
            return message.reply('Vui lòng đặt cược một số tiền hợp lệ.');
        }

        if (userData.money < betAmount) {
            return message.reply('Bạn không đủ tiền để đặt cược.');
        }

        const result = Math.random() < 0.5 ? 'thắng' : 'thua';
        const multiplier = result === 'thắng' ? 1.5 : 0;

        userData.money += Math.floor(betAmount * multiplier) - betAmount;
        userData.cooldowns.coinflip = now;

        const embed = new EmbedBuilder()
            .setColor(result === 'thắng' ? '#00FF00' : '#FF0000')
            .setTitle('🎲 Kết quả cá cược')
            .setDescription(
                `Bạn đã đặt cược ${betAmount} ${config.currency.icon}.\nKết quả: **${result}**!\n${
                    result === 'thắng'
                        ? `Bạn nhận được ${Math.floor(betAmount * 1.5)} ${config.currency.icon}.`
                        : 'Bạn đã mất toàn bộ tiền cược.'
                }`
            );
        message.reply({ embeds: [embed] });
    },
};

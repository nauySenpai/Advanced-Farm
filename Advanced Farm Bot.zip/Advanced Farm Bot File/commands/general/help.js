const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'help',
    description: 'Cách sử dụng bot.',
    execute(message, args, client, data, config) {
        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle(':scroll: Hướng dẫn sử dụng bot')
            .setDescription
            (`
> **Giới thiệu:**
> Advanced Farm là 1 trò chơi quản lý nông trại và đua top với mọi người.
> Tại đây bạn có thể trồng cây, nuôi thú, câu cá để kiếm Farnomy.
> Farnomy dùng để mua các vật phẩm trong shop, chơi lật đồng xu, v.v

> **Cách chơi**
> - Lúc mới vào bạn sẽ có 20 ${config.currency.icon}
> - Dùng tiền đó để mua 1 \`wheat\` trong \`shop\`
> - Sau đó dùng lệnh \`farm\` để thu hoạch.
> - Nếu đủ tiền bạn có thể mua các loại cây khác và gia súc khác để nuôi.
> - Lưu ý là chỉ farm được 1 cây/động vật mỗi loại trong 1 lần thôi nha!
> - Mẹo: Mua cần câu rồi sau đó dùng lệnh \'fish\' đi, cá câu được có thể dùng trong lệnh \'farm\' đấy!

> **Mẹo siêu hữu ích:** 
> - Xem đầy đủ tất cả các lệnh bằng \`f!command\`
            `)
            .setFooter({ text: 'Copyright Advanci Team' });

        message.reply({ embeds: [embed] });
    },
};
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'command',
    description: 'Xem danh sách các lệnh.',
    execute(message, args, client, data, config) {
        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('🛠 List command của bot')
            .setDescription('Danh sách các lệnh bạn có thể sử dụng:')
            .addFields(
                { name: '🎁 Tiền tệ', value: '`f!daily`, `f!coinflip`, `f!leaderboard`', inline: false },
                { name: '🌾 Trang trại', value: '`f!farm`, `f!shop`, `f!buy`, `f!bag`', inline: false },
                { name: '🎣 Câu cá', value: '`f!fish`', inline: false },
                { name: '⚙️ Quản trị', value: '`f!setprefix`, `f!ban`, `f!resetdata`, `f!add`, `f!set`', inline: false },
                { name: '📕 Hướng Dẫn', value: '`f!help`, `f!command`, `f!invite`', inline: false }
            )
            .setFooter({ text: 'Copyright Advanci Team' });

        message.reply({ embeds: [embed] });
    },
};

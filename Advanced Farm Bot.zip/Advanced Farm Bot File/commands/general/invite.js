const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'invite',
    description: 'Mời bot vào máy chủ',
    execute(message, args, client, data, config) {
        const embed = new EmbedBuilder()
            .setColor('#FFD700')
            .setTitle('🔰 Mời bot vào máy chủ của bạn')
            .setDescription
            (`
- Mời bot vào server của bạn: [nhấn vào đây](<https://discordapp.com/oauth2/authorize?client_id=1314849838214676492&scope=bot&permissions=70601793>)

- Server hỗ trợ: [.gg/rGQ5xn9pnf](<https://discord.gg/rGQ5xn9pnf>)
            `)
            .setFooter({ text: 'Copyright Advanci Team' });

        message.reply({ embeds: [embed] });
    },
};

module.exports = {
    createEmbed: (description, color) => ({
        embeds: [
            {
                description,
                color,
                timestamp: new Date(),
            }
        ]
    })
};

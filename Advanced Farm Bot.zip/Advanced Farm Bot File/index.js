const fs = require('fs');
const { EmbedBuilder } = require('discord.js');
const { Client, GatewayIntentBits, Collection } = require('discord.js');

const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent],
});
client.commands = new Collection();

const config = require('./config.json');
const dataPath = './data/data.json';
const formatPath = './data/data-format.json';

let data = require(dataPath);
const dataFormat = require(formatPath);

// Hàm tiện ích để lưu dữ liệu
function saveData() {
    fs.writeFileSync(dataPath, JSON.stringify(data, null, 2), (err) => {
        if (err) console.error('Lỗi khi lưu dữ liệu:', err);
    });
}

// Load commands
const commandFolders = fs.readdirSync('./commands');
for (const folder of commandFolders) {
    const commandFiles = fs
        .readdirSync(`./commands/${folder}`)
        .filter((file) => file.endsWith('.js'));
    for (const file of commandFiles) {
        const command = require(`./commands/${folder}/${file}`);
        client.commands.set(command.name, command);
    }
}

// Bot ready
client.once('ready', () => {
    console.log(`Bot đã sẵn sàng! Đăng nhập với ${client.user.tag}`);
});

// Handle message
client.on('messageCreate', (message) => {
    if (message.author.bot || !message.guild) return;

    const prefix = config.prefix;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName);
    if (!command) return;

    // Ensure user data exists
    if (!data.users[message.author.id]) {
        data.users[message.author.id] = JSON.parse(JSON.stringify(dataFormat));
        saveData();
    }

    // Execute command
    try {
        command.execute(message, args, client, data, config);
        saveData(); // Lưu lại ngay sau khi thực hiện lệnh
    } catch (error) {
        console.error(error);
        message.reply('Đã xảy ra lỗi khi chạy lệnh này.');
    }
});

// Save data on exit
process.on('SIGINT', () => {
    console.log('Đang lưu dữ liệu trước khi thoát...');
    saveData();
    process.exit();
});

client.login(config.token);
